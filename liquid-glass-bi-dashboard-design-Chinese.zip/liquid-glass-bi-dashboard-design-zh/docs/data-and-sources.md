# 数据与来源

## 年度快照

Apple FY2026 Form 10-K 提供 FY2024–FY2026 的可比年度数据，报表按公司财年展示。财年期末分别是 2024-09-28、2025-09-27 和 2026-09-26。底层金额保留为百万美元整数，展示时除以 1,000 转换为十亿美元。

| 文件 | 粒度 | 10-K 位置 |
|---|---|---|
| `data/Finance.csv` | 每财年一行 | Item 8, Consolidated Statements of Operations, p. 32 |
| `data/ProductSales.csv` | 每财年 × 品类一行 | Item 7, Products and Services Performance, p. 26 |
| `data/RegionSales.csv` | 每财年 × 报告地区一行 | Item 7, Segment Operating Performance, p. 25；Note 14, p. 52 |
| `data/FiscalYear.csv` | 每个可选财年一行 | 由快照覆盖的三个财年派生 |

[Apple Inc. FY2026 Form 10-K · SEC EDGAR](https://www.sec.gov/Archives/edgar/data/320193/000032019326000026/aapl-20260926.htm)

`Wearables etc.` 是图表上的缩写，对应年报里的 **Wearables, Home and Accessories**。地区沿用 Apple 的五个报告分部。品类和地区是两个独立的收入切面，各自都与公司总净销售额核对。两张明细表之间没有产品 × 地区的交叉粒度。

## 指标口径

| 指标 | 计算方式 |
|---|---|
| Net sales / Net income | 所选财年的公司净销售额 / 净利润 |
| Sales growth YoY | （本年净销售额 − 上年净销售额）÷ 上年净销售额 |
| Gross margin | 毛利额 ÷ 净销售额 |
| Net margin | 净利润 ÷ 净销售额 |
| Services share / Americas share | 服务或美洲净销售额 ÷ 公司总净销售额 |
| Year-over-year change | 各品类或地区的本年净销售额 − 上年净销售额 |

快照最早覆盖 FY2024，所以该年缺少上年基线。同比卡片和变化图返回空值。选中其它年度后，比较图按当年收入降序排列，变化图按同比增减额降序排列。

中英文包均内置口径一致的语义模型。`Period`、`Category` 和 `Segment` 用于英文报表，相应的 `CN` 字段用于中文报表。年度选择表按同一个数字财年编号计算 DAX 度量，因此两种语言的筛选与度量口径一致。相邻财年的比较以 `选中财年 − 1` 计算。年度趋势和合并财务表固定覆盖 FY2024–FY2026。清空年度选择时，KPI 与所选年度明细回退到快照中的最大财年。

## 模型更新

语义模型内的 Power Query `#table` 是 Power BI 实际读取的数据，仓库中的 CSV 是便于审阅的对应快照。替换样例时，在 Power Query 编辑对应的内嵌表，或接入自有数据源并保持字段名与类型。新增财年时同时维护年度选择表和 CSV，重新核对两个独立收入切面与财务总额。

## 设计与实现参考

- Apple 的材质设计指南用于参考透明度、层级与对比度。[Apple Human Interface Guidelines · Materials](https://developer.apple.com/design/human-interface-guidelines/materials)
- 蓦然JL 的文章用于核对玻璃中心、折射边缘、高光和阴影的设计分工。浏览器样片采用其推荐方案中展示的 SVG 位移图思路，使用本项目自己的位移曲线与布局。[HTML + CSS 实现 Liquid Glass 液态玻璃效果](https://www.cnblogs.com/moranjl/p/18960018) · [Shu Ding 的 Liquid Glass 实现](https://github.com/shuding/liquid-glass)
- Microsoft 的项目样例用于核对 PBIP 目录、相对语义模型引用、TMDL 组织和主题 Schema。[microsoft/Analysis-Services](https://github.com/microsoft/Analysis-Services/tree/master/pbidevmode/fabricps-pbip/SamplePBIP) · [microsoft/powerbi-desktop-samples](https://github.com/microsoft/powerbi-desktop-samples)
- GitHub 社区的 PBIR 示例用于核对原生卡片、图表、切片器和注册资源结构。[data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development/tree/main/plugins/pbip/skills/pbir-format)
- `StaticResources/SharedResources/BaseThemes/CY23SU04.json` 来自 Microsoft 发布的 Sales PBIP 示例。保留原内容，为自定义主题提供默认样式。[原始主题](https://github.com/microsoft/Analysis-Services/blob/master/pbidevmode/fabricps-pbip/SamplePBIP/Sales.Report/StaticResources/SharedResources/BaseThemes/CY23SU04.json) · [Microsoft MIT 许可证](MICROSOFT-LICENSE.txt)

## 设计与复用

画布使用 1440 × 900 的 16:10 比例，四周留约 48 px。标题使用原生文本框，导航使用页面切换按钮，财年使用下拉切片器。图表和表格保留原生工具提示与筛选体验。

| 元素 | 参数 |
|---|---|
| 画布资源 | 2880 × 1800 PNG，2 倍像素密度 |
| 玻璃面 | 摄影背景提升暗部并适度降低饱和度。分析区使用轻度模糊，导航和财年控件采用清晰玻璃 |
| 折射边缘 | 分析面板的位移仅作用于约 19 px 的内缘，沿轮廓法线重采样，位移平滑衰减到零 |
| 轮廓 | 固定圆角矩形，面板半径约 28 px，阴影集中在下缘 |
| 文字 | Microsoft YaHei，正文 `#23394B`，标题 `#101E30` |
| 强调色 | 深蓝、海青、沙丘棕、珊瑚棕和紫罗兰 |

五张背景图在 `PrismFinance-ZH.Report/StaticResources/RegisteredResources/`，文件名以 `-glass.png` 结尾。每张底图包含照片或原创背景及对应的折射。图表和筛选在 Power BI 里保持交互。

浏览器样片把横向、纵向两组位移向量编码到一张图的 R、G 通道，用 `feDisplacementMap` 对玻璃下方的当前画面取样。使用「测试网格」和「折射」开关可以对照边缘与中心。[玻璃折射样片](../assets/glass-demo.html)

更换照片时，使用 [底图生成脚本](../tools/render_glass.py)，依赖 Python、NumPy 和 Pillow 9.1 或更新版本。以下命令把自选照片做成产品页的折射背景。生成后在 Power BI 的画布背景中导入 PNG。可用 `--center X Y` 调节裁切位置，坐标范围为 0 到 1。

```powershell
python tools/render_glass.py --page products --photo "my-photo.jpg" --output "products-glass.png"
```

改动布局时同步调整脚本中的面板位置和 PBIR 的 `visual.json` 坐标。只调整颜色或文字样式时，可以编辑主题 JSON，或在 Desktop 的格式窗格中操作。`assets/` 的 PNG 用实际 FY2026 数据绘制，用于展示设计。

## 照片署名

项目中的摄影背景经过裁切并调亮暗部，报表底图和预览还合成了玻璃折射。盈利能力和数据明细页为原创程序绘制。

| 页面 | 摄影作品 | 作者 | 许可 |
|---|---|---|---|
| Overview | [Apple Park 2022](https://commons.wikimedia.org/wiki/File:Apple_Park_2022.jpg) | InvadingInvader | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Products & Services | [An aerial view of a beach and the ocean](https://unsplash.com/photos/an-aerial-view-of-a-beach-and-the-ocean-Uv6hsAgGR_U) | Graddes | [Unsplash License](https://unsplash.com/license) |
| Geographies | [Aerial view of dune field](https://commons.wikimedia.org/wiki/File:Aerial_view_of_dune_field_(fdeebae4-155d-451f-67e5-67fa0e9a2530).JPG) | U.S. National Park Service | 美国公有领域 |

本版本总览设计预览、HTML 样片以及报表的 `overview-glass.png` 中，Apple Park 摄影改编部分按 CC BY-SA 4.0 分发。其余独立报表定义、脚本与原创设计资产使用项目的 MIT 许可。
