# Liquid Glass BI Dashboard Design

A Power BI dashboard theme inspired by Apple’s Liquid Glass, with translucent panels, soft Gaussian blur, and subtle edge refraction. The included offline HTML demo lets you drag the glass and test real-time refraction across five backgrounds.

基于 Apple 液态玻璃风格设计的 Power BI 看板主题，以通透的玻璃、柔和的高斯模糊和细腻的边缘折射呈现简约质感。附可离线打开的 HTML 交互样片，支持切换五种背景、拖动玻璃，并开关折射效果进行实时对照。

## 中文版

![财务总览设计预览](assets/zh/overview.png)

- [Power BI 项目](PrismFinance-ZH.pbip)。解压整个 ZIP，在 Windows Power BI Desktop 打开 PBIP。保留 `PrismFinance-ZH.Report/` 和 `PrismFinance.SemanticModel/` 的相对位置。
- [离线 HTML 样片](assets/glass-demo.html)。在浏览器打开即可拖动玻璃、切换背景并比较折射效果。
- [数据说明与照片署名](docs/data-and-sources.md) · [MIT 许可证](LICENSE)

首次打开若图表为空，点 **主页 → 刷新**。财务快照内置在语义模型中，刷新无需外部凭据。Power BI 的折射底图为预渲染素材，浏览器样片使用实时折射。
