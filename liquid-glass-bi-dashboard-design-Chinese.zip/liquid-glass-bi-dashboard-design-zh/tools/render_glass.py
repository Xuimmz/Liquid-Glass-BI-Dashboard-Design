import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter, ImageOps

WIDTH, HEIGHT = 1440, 900
NAV = [(704, 39, 101, 42), (808, 39, 99, 42), (910, 39, 98, 42), (1011, 39, 120, 42), (1134, 39, 89, 42)]
YEAR_BOX = (1234, 31, 156, 58)
OVERVIEW_PANELS = [(48, 225, 414, 159), (478, 225, 294, 159), (788, 225, 294, 159),
                   (1098, 225, 294, 159), (48, 408, 817, 404), (885, 408, 507, 404)]
DETAIL_PANELS = [(48, 225, 448, 159), (512, 225, 432, 159), (960, 225, 432, 159),
                 (48, 408, 817, 404), (885, 408, 507, 404)]
DATA_PANELS = [(48, 225, 1344, 251), (48, 496, 663, 316), (729, 496, 663, 316)]
SCALE = 2
SIZE = WIDTH * SCALE, HEIGHT * SCALE
TINTS = {
    'overview': (255, 252, 246),
    'products': (246, 253, 255),
    'regions': (255, 252, 245),
    'margins': (255, 249, 247),
    'data': (248, 250, 255),
}


def fade(array, color, opacity):
    return array + (np.asarray(color, dtype=np.float32) - array) * opacity[..., None]


def smoothstep(value):
    value = np.clip(value, 0, 1)
    return value * value * (3 - 2 * value)


def rim_offset(distance, band, bend):
    return bend * (1 - smoothstep(distance / band)) * (distance >= 0)


def daylight_photo(photo_path, size, center, bleed):
    with Image.open(photo_path) as source:
        photo = ImageOps.fit(ImageOps.exif_transpose(source).convert('RGB'), size,
                             Image.Resampling.LANCZOS, bleed=bleed, centering=center)
    pixels = np.asarray(photo, dtype=np.float32) / 255
    lifted = 255 * np.power(pixels, .69)
    luma = lifted @ np.array([.2126, .7152, .0722], dtype=np.float32)
    return .88 * lifted + .12 * luma[..., None]


def backdrop(page, photo_path=None, center=(.5, .5), bleed=0):
    height, width = SIZE[1], SIZE[0]
    y, x = np.ogrid[0:1:complex(0, height), 0:1:complex(0, width)]
    x, y = x.astype(np.float32), y.astype(np.float32)
    if photo_path:
        array = daylight_photo(photo_path, SIZE, center, bleed)
        # Grade the photograph independently of the lens so the optics can stay clear.
        heading = .43 * np.exp(-((x - .10) / .37) ** 4 - ((y - .13) / .16) ** 4)
        data_area = smoothstep((y - .18) / .16)
        luma = array @ np.array([.2126, .7152, .0722], dtype=np.float32)
        lift = .31 * data_area * (1 - luma / 255)
        footer = .11 * smoothstep((y - .88) / .115)
        return fade(array, TINTS[page], np.clip(heading + lift + footer, 0, .79))

    if page == 'margins':
        base = (249, 239, 237)
        glows = [(0.83, .23, .57, .46, (243, 166, 142), .69),
                 (.30, .92, .57, .52, (222, 170, 220), .62)]
        beams = [(.035, .085, (249, 146, 116), .62), (.016, .041, (255, 169, 114), .86),
                 (-.009, .012, (255, 248, 212), .95), (-.026, .028, (255, 192, 143), .73),
                 (-.082, .064, (230, 153, 185), .48)]
        curve = y - (.16 + .55 * x + .14 * np.sin(4.2 * x - .55))
    else:
        base = (231, 239, 254)
        glows = [(.82, .12, .46, .48, (177, 164, 246), .64), (.10, .89, .53, .43, (130, 192, 248), .57)]
        beams = [(.058, .085, (150, 162, 243), .58), (.028, .025, (113, 197, 246), .63),
                 (.010, .009, (213, 253, 255), .90), (-.010, .010, (249, 188, 229), .67),
                 (-.043, .028, (168, 136, 228), .65)]
        curve = y - (.80 - .68 * x + .11 * np.sin(5.2 * x))
    array = np.full((height, width, 3), base, dtype=np.float32)
    for cx, cy, sx, sy, hue, opacity in glows:
        array = fade(array, hue, opacity * np.exp(-((x - cx) / sx) ** 2 - ((y - cy) / sy) ** 2))
    for center, spread, hue, opacity in beams:
        array = fade(array, hue, opacity * np.exp(-((curve - center) / spread) ** 2))
    echo = y - (.97 - .31 * x + .09 * np.sin(6.1 * x + .85))
    array = fade(array, beams[1][2], .28 * np.exp(-((echo + .018) / .045) ** 2))
    grade = .22 * np.exp(-((x - .13) / .25) ** 2 - ((y - .16) / .23) ** 2)
    return fade(array, base, grade)


def sample_channel(channel, x, y):
    x = np.clip(x, 0, channel.shape[1] - 1.001)
    y = np.clip(y, 0, channel.shape[0] - 1.001)
    right_of = x.astype(np.int32)
    below = y.astype(np.int32)
    tx = x - right_of
    ty = y - below
    upper = channel[below, right_of] * (1 - tx) + channel[below, right_of + 1] * tx
    lower = channel[below + 1, right_of] * (1 - tx) + channel[below + 1, right_of + 1] * tx
    return upper * (1 - ty) + lower * ty


def liquid_panel(canvas, source, box, radius, tint, variant):
    left, top, width, height = box
    # The rounded rectangle stays fixed. Its signed distance supplies the lens normal.
    pad = 11
    x0, y0 = max(0, (left - pad) * SCALE), max(0, (top - pad) * SCALE)
    x1, y1 = min(SIZE[0], (left + width + pad) * SCALE), min(SIZE[1], (top + height + pad) * SCALE)
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    x = xx / SCALE - left
    y = yy / SCALE - top

    qx = np.abs(x - width / 2) - width / 2 + radius
    qy = np.abs(y - height / 2) - height / 2 + radius
    distance = radius - np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) - np.minimum(np.maximum(qx, qy), 0)
    coverage = np.clip(distance * SCALE + .5, 0, 1)
    dy, dx = np.gradient(distance)
    normal_length = np.maximum(np.hypot(dx, dy), .0001)
    nx, ny = dx / normal_length, dy / normal_length
    edge = np.maximum(distance, 0)
    band = 19 if variant == 'body' else 12
    # A smooth displacement only at the rim. Everywhere beyond the band maps to itself.
    depth = rim_offset(distance, band, 19 if variant == 'body' else 14)
    refracted = np.empty((*distance.shape, 3), dtype=np.float32)
    sx, sy = xx - SCALE * nx * depth, yy - SCALE * ny * depth
    for channel in range(3):
        refracted[..., channel] = sample_channel(source[..., channel], sx, sy)

    if variant == 'control':
        luma = refracted @ np.array([.2126, .7152, .0722], dtype=np.float32)
        opacity = .35 + .22 * (1 - luma / 255)
    else:
        opacity = np.full_like(edge, .21 if variant == 'body' else .28)
    lit = fade(refracted, tint, opacity)
    top_light = np.clip(.82 * ny + .5 * nx, 0, 1)
    reflection = np.exp(-((edge - .8) / .85) ** 2) * (.17 + .61 * top_light)
    lit = fade(lit, (255, 255, 255), reflection)
    destination = canvas[y0:y1, x0:x1]
    if variant != 'active':
        below = np.maximum(-ny, 0)
        outside_shadow = .095 * np.exp(-((distance + 3.3) / 3.9) ** 2) * below * (1 - coverage)
        destination *= (1 - outside_shadow[..., None])
    destination[:] = fade(destination, lit, coverage)


def render_glass(page, photo_path=None, center=(.5, .5), bleed=0):
    active = list(TINTS).index(page)
    original = backdrop(page, photo_path, center, bleed)
    flat_image = Image.fromarray(np.clip(original, 0, 255).astype('uint8'), 'RGB')
    soft = np.asarray(flat_image.filter(ImageFilter.GaussianBlur(SCALE * 3.2)), dtype=np.float32)
    canvas = original.copy()
    if page == 'overview':
        panels = OVERVIEW_PANELS
    elif page == 'data':
        panels = DATA_PANELS
    else:
        panels = DETAIL_PANELS
    if page != 'data':
        panels = [(48, 225, 1344, 159), *panels[-2:]]
    for box in panels:
        liquid_panel(canvas, soft, box, 28, TINTS[page], 'body')
    liquid_panel(canvas, original, (695, 31, 532, 58), 29, TINTS[page], 'control')
    liquid_panel(canvas, original, YEAR_BOX, 29, TINTS[page], 'control')
    # This shallow lens samples the already composited navigation surface.
    nav = Image.fromarray(np.clip(canvas, 0, 255).astype('uint8'), 'RGB')
    nav_layer = np.asarray(nav, dtype=np.float32)
    liquid_panel(canvas, nav_layer, NAV[active], 21, TINTS[page], 'active')
    result = Image.fromarray(np.clip(canvas, 0, 255).astype('uint8'), 'RGB')
    return result


def main():
    parser = argparse.ArgumentParser(description='Render a refractive Power BI background for a Prism Finance page.')
    parser.add_argument('--page', choices=TINTS, required=True)
    parser.add_argument('--photo', type=Path, help='Input photo. Required for the overview, products, and regions pages.')
    parser.add_argument('--center', type=float, nargs=2, default=(.5, .5), metavar=('X', 'Y'))
    parser.add_argument('--bleed', type=float, default=0, help='Fraction removed from each image edge before fitting.')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.photo is None and args.page not in ('margins', 'data'):
        parser.error('--photo is required for this page')
    if any(not 0 <= position <= 1 for position in args.center) or not 0 <= args.bleed < .5:
        parser.error('center must be between 0 and 1 and bleed must be less than 0.5')
    render_glass(args.page, args.photo, tuple(args.center), args.bleed).save(args.output, optimize=True)


if __name__ == '__main__':
    main()
