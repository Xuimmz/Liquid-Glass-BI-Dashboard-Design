# Liquid Glass BI Dashboard Design

A Power BI dashboard theme inspired by Apple’s Liquid Glass, with translucent panels, soft Gaussian blur, and subtle edge refraction. The included offline HTML demo lets you drag the glass and test real-time refraction across five backgrounds.

基于 Apple 液态玻璃风格设计的 Power BI 看板主题，以通透的玻璃、柔和的高斯模糊和细腻的边缘折射呈现简约质感。附可离线打开的 HTML 交互样片，支持切换五种背景、拖动玻璃，并开关折射效果进行实时对照。

## English edition

![Financial overview design preview](assets/overview.png)

- [Power BI project](PrismFinance.pbip). Extract the full ZIP and open the PBIP in Power BI Desktop for Windows. Keep `PrismFinance.Report/` and `PrismFinance.SemanticModel/` next to the project file.
- [Offline HTML demo](assets/glass-demo-en.html). Open it in your browser to drag the lens, switch backgrounds, and compare refraction on and off.
- [Data definitions and photo credits](docs/data-and-sources.md) · [MIT license](LICENSE)

If the visuals are empty on the first launch, select **Home → Refresh**. The semantic model contains the financial snapshot and needs no external credentials. The Power BI report uses pre-rendered backgrounds. The HTML demo renders refraction in real time.
