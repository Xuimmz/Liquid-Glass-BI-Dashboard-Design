# Data, design, and credits

## Financial data

The dashboard uses fiscal 2024–2026 figures from Apple's FY2026 Form 10-K. The fiscal years ended on September 28, 2024, September 27, 2025, and September 26, 2026. Source amounts are in millions of US dollars, with selected visuals scaling this to billions.

| Snapshot | Grain and filing section |
|---|---|
| `data/Finance.csv` | One row per fiscal year. Item 8, Consolidated Statements of Operations, p. 32. |
| `data/ProductSales.csv` | One row per fiscal year and product category. Item 7, Products and Services Performance, p. 26. |
| `data/RegionSales.csv` | One row per fiscal year and reporting segment. Item 7, Segment Operating Performance, p. 25, and Note 14, p. 52. |
| `data/FiscalYear.csv` | One row per selectable fiscal year. |

[Apple FY2026 Form 10-K](https://www.sec.gov/Archives/edgar/data/320193/000032019326000026/aapl-20260926.htm)

Year-over-year growth is the difference from the previous fiscal year divided by previous-year sales. Gross and net margins divide profit by net sales. Services and Americas shares divide their net sales by companywide net sales. FY2024 has no prior-year comparison in the supplied snapshot. Product categories and geographies are independent revenue breakdowns and each reconciles to consolidated net sales.

The Power Query tables embedded in the TMDL are the report's source. The CSVs mirror that snapshot. The two language editions use the same numerical fiscal-year key and measures. The product and geographic tables also carry localized display labels.

## Reusing the glass design

The 1440 × 900 Power BI canvas uses 2880 × 1800 pre-rendered backgrounds in `PrismFinance.Report/StaticResources/RegisteredResources/`. The [reusable theme](../PrismFinance.Report/StaticResources/RegisteredResources/Prism-Liquid-Glass.json) can be imported through **View → Themes → Browse for themes**. The [rendering script](../tools/render_glass.py) takes a replacement photo and generates a background with the refractive edges. It requires Python, NumPy, and Pillow 9.1 or later.

```powershell
python tools/render_glass.py --page products --photo "my-photo.jpg" --output "products-glass.png"
```

The [offline HTML demo](../assets/glass-demo-en.html) uses SVG's `feDisplacementMap` to apply live displacement near the lens rim. Switch to Test Grid and toggle Refraction to compare the edge and center.

## Photography and references

| Scene | Credit and original license |
|---|---|
| Apple Park | InvadingInvader, [Apple Park 2022](https://commons.wikimedia.org/wiki/File:Apple_Park_2022.jpg), [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Coast | Graddes, [An aerial view of a beach and the ocean](https://unsplash.com/photos/an-aerial-view-of-a-beach-and-the-ocean-Uv6hsAgGR_U), [Unsplash License](https://unsplash.com/license) |
| White Sands | U.S. National Park Service, [Aerial view of dune field](https://commons.wikimedia.org/wiki/File:Aerial_view_of_dune_field_(fdeebae4-155d-451f-67e5-67fa0e9a2530).JPG), United States public domain |

Apple Park photo adaptations in the overview background, design preview, and HTML demo are distributed under CC BY-SA 4.0. The Profitability and Data Explorer backgrounds are original artwork. The original project source is MIT licensed. The Microsoft CY23SU04 base theme retains its separate [Microsoft MIT license](MICROSOFT-LICENSE.txt).

- [Apple Human Interface Guidelines · Materials](https://developer.apple.com/design/human-interface-guidelines/materials)
- [Liquid Glass reference article](https://www.cnblogs.com/moranjl/p/18960018) and [Shu Ding's SVG example](https://github.com/shuding/liquid-glass)
- [Microsoft sample Power BI project](https://github.com/microsoft/Analysis-Services/tree/master/pbidevmode/fabricps-pbip/SamplePBIP)
- [Microsoft Power BI Desktop samples](https://github.com/microsoft/powerbi-desktop-samples)
- [Community PBIR examples](https://github.com/data-goblin/power-bi-agentic-development/tree/main/plugins/pbip/skills/pbir-format)
